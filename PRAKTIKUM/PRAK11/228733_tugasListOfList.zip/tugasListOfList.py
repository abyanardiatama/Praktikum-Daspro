"""
NIM           :
Nama        :
Deskripsi   : 
Tanggal     :
"""
"""Ex:
Matrix2 = [[1,2,3],[4,5,6],[7,8,9]]
Matrix1 = [
              [1,2,3],
              [4,5,6],
              [7,8,9]
              ]
"""
# 1
# DefSpek
# NbEleX : elemen, list of list --> integer
# NbEleX (L,X) menentukan banyaknya X dalam list L
# L1 = [[4], 2, [3,4], 1, 4]
# aplikasi : NbEleX(L1,4) --> 3 

# 2
# DefSpek
# KaliMatrix : Integer, list of list dalam bentuk matrix --> list
# KaliMatrix (k, L) menghasilkan matrix dalama bentuk list
# yang telah dikali dengan suatu konstanta K
# L3 = [[1,2,3], [4,5,6], [7,8,9]]
# aplikasi : KaliMatrix(2, L3) --> [[2,4,6],[8,10,12],[14,16,18]]

# 3
# DefSpek
# NbList : list of list --> integer
# NbList (L) menghitung jumlah list dalam list L
# L4 = [1, [2,3], [4]]
# L3 = [[5], [6], [7]]
# L2 = [8, 9, 10]
# aplikasi : NbList(L4) --> 2
#               NbList(L3) --> 3
#               NbList(L2) --> 0