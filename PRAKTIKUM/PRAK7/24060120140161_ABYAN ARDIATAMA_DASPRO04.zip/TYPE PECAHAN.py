#Nama File  : pecahan.py
#Deskripsi  : Membuat tipe pecahan beserta konstruktor dan selektornya
#Pembuat    : Abyan A.
#Tanggal    : 6 Oktober 2020

#DEFINISI TYPE
# type pecahan : < n:integer >=0, d:integer>0 >
#   {n:integer >=0, d:integer>0 n adalah pembilang(numerator) dan d adalah penyebut(denumerator). Penebut tidak boleh nol}

#DEFINISI DAN SPESIFIKASI KONSTRUKTOR
# MakeP : integer >=0, integer>0 --> pecahan
#   {Make(x,y) membentuk sebuah pecahan dari pembilang x dan penyebut y, dengan x dan y integer}


#DEFINISI DAN SPRESIFIKASI SELEKTOR DENGAN FUNGSI
# Pemb : pecahan --> integer
#   {Pemb(p) memberikan numerator pembilang n dari pecahan tersebut}

# Peny : pecahan --> integer
#   {Peny(p) memberikan denumerator penyebut d dari pecahan tersebut}


#DEFINISI DAN SPESIFIKASI OPERATOR TERHADAP PECAHAN
# AddP : 2 pecahan --> pecahan
#   {AddP(P1,P2) menambahkan 2 buah pecahan P1 dan P2 : n1/d1 + n2/d2 = (n1*d2 + n2*d1)/d1*d2}

# SubP : 2 pecahan --> pecahan
#   {Sub(P1,P2) mengurangkan 2 buah pecahan P1 dan P2 : n1/d1 - n2/d2 = (n1*d2 - n2*d1)/d1*d2}

# MulP : 2 pecahan --> pecahan
#   {MulP(P1,P2) mengalikan 2 buah pecahan P1 dan P2 : n1/d1 * n2/d2 = (n1*n2)/(d1*d2)}

# DivP : 2 pecahan --> pecahan
#   {DivP(P1,P2) membagi 2 buah pecahan P1 dan P2 : (n1/d1) / (n2/d2) = (n1*d2) / (n2*d1)}

# RealP : 2 pecahan --> real
#   {Menulis bilangan pecahan dalam notasi desimal}


#DEFINISI DAN SPESIFIKASI PREDIKAT
# Is_eqP : 2 pecahan --> booelan
#   {Is_EqP(P1,P2) bernilai true jika P1=P2 : n1/d1 = n2/d2 jika dan hanya jika n1*d2 = n2*d1}

# Is_LtP : 2 pecahan --> boolean
#   {Is_LtP(P1,P2) bernilai true jika P1<P2 : n1/d1 < n2/d2 jika dan hanya jika n1*d2 < n2*d1}

# Is_GtP : 2 pecahan --> boolean
#   {Is_GtP(P1,P2) bernilai true jika P1>P2 : n1/d1 > n2/d2 jika dan hanya jika n1*d2 > n2*d1}

############################################################################################################################
#REALISASI TYPE
class pecahan:
    def __init__(self,a,b):
        self.x = a
        self.y = b

#REALISASI  SELEKTOR DENGAN FUNGSI
def pemb(P):
    return P.x
def peny(P):
    return P.y

#REALISASI KONSTRUKTOR
def MakeP(x,y):
    return pecahan(x,y)

#REALISASI OPERASI TERHADAP PECAHAN
def AddP(P1,P2):
    x=(pemb(P1)*peny(P2))+(pemb(P2)*peny(P1))
    y= peny(P1)*peny(P2)
    return(x,y)
    
def SubP(P1,P2):
    j=(pemb(P1)*peny(P2)) - (pemb(P2)*peny(P1))
    k=(peny(P1)*peny(P2))
    return (j,k)

def MulP(P1,P2):
    c=(pemb(P1)*pemb(P2))
    d=(peny(P1)*peny(P2))
    return(c,d)

def DivP(P1,P2):
    e=pemb(P1)*peny(P2)
    f=pemb(P2)*peny(P1)
    return(e,f)

def RealP(P):
    return pemb(P)/peny(P)

#REALISASI PREDIKAT
def Is_EqP(P1,P2):
    return pemb(P1)*peny(P2)== pemb(P2)*peny(P1)

def Is_LtP(P1,P2):
    return pemb(P1)*peny(P2) < pemb(P2)*peny(P1)

def Is_GtP (P1,P2):
    return pemb(P1)*peny(P2) > pemb(P2)*peny(P1)

#############################################################################################################################
#APLIKASI 
p = pecahan(3,5)
q = pecahan(10,5)
r = pecahan(75,125)
s = pecahan(22,7)

print (pemb(p))
print (peny(q))
print (MakeP(p,q))
print (AddP(p,q))
print (SubP(p,q))
print (MulP(p,q))
print (DivP(p,q))
print (RealP(p))
print (RealP(q))
print (RealP(s))
print (Is_EqP(p,r))
print (Is_LtP(p,q))
print (Is_GtP(p,q))
