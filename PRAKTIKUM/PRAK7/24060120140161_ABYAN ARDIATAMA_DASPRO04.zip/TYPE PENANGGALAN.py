#Nama File  : type penanggalan.py
#Deskripsi  : Membuat tipe penanggalan beserta konstruktor dan selektornya
#Pembuat    : Abyan A.
#Tanggal    : 6 Oktober 2020

#DEFINISI DAN TYPE DATE
# type Hr : integer [1...31]
#   {definisi ini hanya untuk menamakan type integer dengan nilai tertentu supaya mewakili hari]

# type Bln : integer [1...12]
#   {definisi ini hanya untuk menamakan type integer dengan nilai tertentu supaya mewakili bulan}

# type Thn : integer>0
#   {definisi ini hanya untuk menamakan type integer dengan nilai tertentu supaya mewakili tahun}

# type date : <d:Hr, m:Bln, y:Thn>
#   {<d,m,y> adalah type date dengan tanggal d, bulan m, dan tahun y}

#DEFINISI DAN SPESIFIKASI SELEKTOR
# Day : date --> Hr
#   {Day(D) memberikan hari d dari D yang terdiri dari <d,m,y>}

# Month : date --> Bln
#   {Day(D) memberikan bulan m dari D yang terdiri dari <d,m,y>}

# Year : date --> Thn
#   {Day(D) memberikan tahun y dari D yang terdiri dari <d,m,y>}

#KONSTRUKTOR
# MakeDate : <Hr,Bln,Thn> --> date
#   {MakeDate<h,b,t> --> tanggal pada hari, bulan, tahun yang bersangkutan}

#DEFINISI DAN SPESIFIKASI OPERATOR/FUNGSI LAIN TERHADAP DATE
# Nextday : date --> date
#   {Nextday(D) menghitung date yang merupakan keesokan hari dari date D yang diberikan}

# Yesterday : date --> date
#   {Yesterday(D) menghitung date yang merupakan 1 hari sebelum date D yang diberikan}

# NextNday : date, integer --> date
#   {NextNday(D) mengitung date yang merupakan N hari setelah date D yang diberikan}

# Harike1900 : date --> integer[0...366]
#   {Harike1900(D) menghitung jumlah hari terhadap 1 Januari pada tahun y, dengan memperhatikan apakah y adalah tahun adalah tahun kabisat}

#DEFINISI DAN SPESIFIKASI PREDIKAT
# IsEqD : 2 date --> boolean
#   {Is_EqD(d1,d2) bernilai true jika d1=d2 and m1=m2 and y1=y2}

# Is_before : 2 date --> boolean
#   {Is_before(d1,d2) bernilai true jika d1 adalah sebelum d2}

# Is_after : 2 date --> boolean
#   {Is_before(d1,d2) bernilai true jika d1 adalah sesudah d2}

# dpm : integer --> integer
#   {dpm(b) menentukan jumlah hari mulai dari 1 Januari hingga tanggal 1 bulan berikutnya}
# Is_kabisar : integer>0 --> boolean
#   {is_kabisat(x) bernilai true jika tahun 1900+x adalah tahun kabisat : habis dibagi 4 tetapi tidak habis dibagi 100, atau habis dibagi 400}

################################################################################################################################################################
#REALISASI TYPE
class date:
    def __init__ (self,Hr,Bln,Thn):
        self.d = Hr
        self.m = Bln
        self.y = Thn
        
################################################################################################################################################################
#REALISASI SELEKTOR
def tgl(D):
    return D.d
def bln(D):
    return D.m
def thn(D):
    return D.y

################################################################################################################################################################
#REALISASI KONSTRUKTOR
def make_date(d,m,y):
    return (d,m,y)

################################################################################################################################################################
#REALISASI PREDIKAT
def is_before(D1,D2):
    J1=tgl(D1)
    M1=bln(D1)
    T1=thn(D1)
    J2=tgl(D2)
    M2=bln(D2)
    T2=thn(D2)
    if T1 != T2:
        return T1<T2
    elif M1!= M2:
        return M1<M2
    elif J1 != J2:
        return J1<J2

def is_after(D1,D2):
    return
    J1=tgl(D1)
    M1=bln(D1)
    T1=thn(D1)
    J2=tgl(D2)
    M2=bln(D2)
    T2=thn(D2)
    if T1 != T2:
        return T1>T2
    elif M1!= M2:
        return M1>M2
    elif J1 != J2:
        return J1>J2

def is_EqD(D1,D2):
    return tgl(D1)== tgl(D2) and bln(D1)== bln(D2) and thn(D1)== thn(D2)

def is_kabisat(x):
    return x%4==0 and x%100!=0 or x//400==0

################################################################################################################################################################
#REALISASI OPERATOR TERHADAP DATE   
def nextday(D):
    a = tgl(D)
    b = bln(D)
    c = thn(D)
    d = tgl(D)+1
    e = bln(D)+1
    f = thn(D)+1
    #BULAN DENGAN 31 HARI
    if tgl(D)<31 and bln(D)==1 or bln(D)==3 or bln(D)==5 or bln(D)==7 or bln(D)==8 or bln(D)==10:
        return (d,b,c)
    elif tgl(D)==31 and bln(D)==1 or bln(D)==3 or bln(D)==5 or bln(D)==7 or bln(D)==8 or bln(D)==10:
        return (1,e,c)
    #BULAN FEBRUARI KABISAT
    elif tgl(D) == 28 and is_kabisat(thn(D)):
        return(d,b,c)
    elif tgl(D)==29 and is_kabisat(thn(D)):
        return(1,e,c)
    #BULAN FEBRUARI BUKAN KABISAT
    elif tgl(D)<28 and bln(D)==2:
        return (d,b,c)
    elif tgl(D)== 28 and bln(D)==2:
        return(1,e,c)
    #BULAN DENGAN 30 HARI
    if tgl(D)<30 and bln(D)==4 or bln(D)==6 or bln(D)==9 or bln(D)==11:
        return (d,b,c)
    elif tgl(D)==30 and bln(D)==4 or bln(D)==6 or bln(D)==9 or bln(D)==11:
        return (1,e,c)
    #BULAN DESEMBER
    elif tgl(D)<31 and bln(D)==12:
        return(d,b,c)
    elif tgl(D)==31 and bln(D)==12:
        return(1,1,f)

def yesterday(D):
    a=tgl(D)
    b=bln(D)
    c=thn(D)
    d=tgl(D)-1
    e=bln(D)-1
    f=thn(D)-1
    #BULAN MARET KE FEBRUARI KABISAT
    if tgl(D)==1 and (bln(D)==3 and is_kabisat(thn(D))):
        return (29,e,c)
    #BULAN MARET KE FEBRUARI
    elif tgl(D)==1 and bln(D)==3:
        return(28,e,c)
    #BULAN 31 HARI
    elif tgl(D)==1 and (bln(D)==3 or bln(D)==5 or bln(D)==7 or bln(D)==8 or bln(D)==10 or bln(D)==12):
        return(30,e,c)
    #BULAN 30 HARI
    elif tgl(D)==1 and (bln(D)==4 or bln(D)==6 or bln(D)==9 or bln(D)==11):
        return (31,e,c)
    #BULAN JANUARI KE DESEMBER
    elif tgl(D)==1 and bln(D)==1:
        return(31,12,f)
    else:
        return(d,b,c)


def nextNday(D,N):
    a= tgl(D)+N - 31
    b= tgl(D)+N - 30
    c= tgl(D)+N - 29
    d= tgl(D)+N - 28
    e= tgl(D)+N
    f= bln(D)
    g= bln(D)+1
    h= thn(D)
    i= thn(D)+1

    # BULAN 31 HARI
    if tgl(D)+N > 31 and (bln(D)==1 or bln(D)== 3 or bln(D)==5 or bln(D)==7 or bln(D)==8 or bln(D)==10):
        return (a,g,h)
    elif tgl(D)+N <= 31 and (bln(D)==1 or bln(D)== 3 or bln(D)==5 or bln(D)==7 or bln(D)==8 or bln(D)==10):
        return (e,f,h)
    
    #BULAN 30 HARI
    elif tgl(D)+N > 30 and (bln(D)==4 or bln(D)==6 or bln(D)==9 or bln(D)==11):
        return (b,g,h)
    elif tgl(D)+N <= 30 and (bln(D)==4 or bln(D)==6 or bln(D)==9 or bln(D)==11):
        return (e,f,h)
    
    #BULAN FEBRUARI KABISAT
    elif tgl(D)+N> 29 and bln(D)==2 and is_kabisat(thn(D)):
        return (c,g,h)
    elif tgl(D)+N<= 29 and bln(D)==2 and is_kabisat(thn(D)):
        return (e,f,h)
    #BULAN FEBRUARI
    if tgl(D)+N > 28 and bln(D)==2:
        return (g,h,c)
    elif tgl(D)+N<= 28 and bln(D)==2:
        return (e,f,h)
    
    #BULAN DESEMBER
    elif tgl(D)+N > 31 and bln(D)==12:
        return (a,1,i)
    elif tgl(D)+N<= 31 and bln(D)==12:
        return(e,f,h)

def dpm(b):
    if b==1:
        return 1
    elif b==2:
        return 32
    elif b==3:
        return 60
    elif b==4:
        return 91
    elif b==5:
        return 121
    elif b==6:
        return 152
    elif b==7:
        return 182
    elif b==8:
        return 213
    elif b==9:
        return 244
    elif b==10:
        return 274
    elif b==11:
        return 305
    elif b==12:
        return 335
def harike1900(D):
   return dpm(bln(D))+ tgl(D)-1+ 1 if bln(D)>2 and is_kabisat(thn(D)) else dpm(bln(D))+tgl(D)-1+0


################################################################################################################################################################
#APLIKASI
A = date(23,11,2001)
B = date(17,8,1945)

print(tgl(A))
print(bln(B))
print(thn(B))
print(make_date(9,11,2001))
print(is_before(A,B))
print(is_after(A,B))
print(is_EqD(B,A))
print(is_kabisat(1945))
print(nextday(B))
print(yesterday(A))
print(nextNday(B,28))
print(harike1900(B))

