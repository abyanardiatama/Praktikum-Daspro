#Nama File  : type point.py
#Deskripsi  : membuat tipe point beserta konstruktor dan selektornya
#Pembuat    : Abyan A.
#Tanggal    : 9 Oktober 2020

#DEFINISI TYPE
# type point : <x=real, y=real>
#   {x=real, y=real adalah sebuah point dimana x sebagai absis dan y sebagai ordinat}

#DEFINISI DAN SPESIFIKASI KONSTRUKTOR
# make_point : 2 real --> point
#   {make_point(a,b) membentuk point dari a dan b dimana a sebagai absis dan b sebagai ordinat}

#DEFINISI DAN SPESIFIKASI SELEKTOR DENGAN FUNGSI
# absis : point --> real
#   {absis(P) menentukan nilai absis pada point P}
# ordinat : point --> real
#   {ordinat(P) menentukan nilai ordinat pada point P}

#DEFINISI DAN SPESIFIKASI OPERATOR TERHADAP POINT
# gradien : 2 point --> integer
#   {gradien(P1,P2) menghitung gradien suatu garis dari 2 buah point}
# isSejajar : 4 point --> integer
#   {isSejajar(Q1,Q2,Q3,Q4) menentukan apakah gradien garis pertama(Q1,Q2) sama dengan gradien garis kedua(Q3,Q4)}
# isTegakLurus : 4 point --> integer
#   {isTegakLurus(R1,R2,R3,R4) menentukan apakah gradien garis pertama(R1,R2) tegak lurus dengan garis kedua(R3.R4)}



############################################################################################################################
#REALISASI TYPE
class point:
    def __init__(self,a,b):
        self.x=a
        self.y=b

#REALISASI KONSTRUKTOR
def make_point(a,b)
    return (a,b)

#REALISASI SELEKTOR
def absis(P):
    return P.x

def ordinat(P):
    return P.y

#REALISASI OPERATOR TERHADAP POINT
def gradien(P1,P2):
    a= ordinat(P2)-ordinat(P1)
    b= absis(P2) - absis(P1)
    return (a//b)

def isSejajar(Q1,Q2,Q3,Q4):
    return gradien(Q1,Q2) == gradien(Q3,Q4)

def isTegakLurus(R1,R2,R3,R4):
    return gradien(R1,R2)* gradien(R3,R4) == -1

############################################################################################################################
#APLIKASI TYPE
P = point(3,6)
Q = point(5,7)
R = point(10,5)
S = point(4,7)

#APLIKASI OPERATOR
print (gradien(P,Q))
print (gradien(R,S))
print (isSejajar(P,Q,R,S))
print (isTegakLurus(P,Q,R,S))
